/* ============================================================
   JOB:      STI_CA_D_ORCHESTRATOR
   STATUS:   PROD
   PURPOSE:  Daily Campaign Drop Orchestrator
             Reads approved redrop requests from SharePoint,
             resolves each to its campaign SAS file by name,
             injects run parameters, and fires %include.
             The campaign file builds the population and drops
             it directly into the Optimise intake folder.
             Optimise handles all filtering from there.

   SCHEDULE: Daily - runs AFTER STI_CA_D_APNS_DATA completes
             so APNS_DATA is fresh when campaign files query it
             to exclude leads already sent to Adobe.

   HOW IT WORKS:
     1. Reads REDROP_REQUESTS.xlsx from SharePoint
     2. Reads APPROVERS sheet - validates who can approve
     3. For each approved request:
          a. Constructs file path:
             &base_path. + campaign_code + "_DROP.sas"
          b. Checks file exists
          c. Looks up most recent load_date from OFFER_CHECKOUT
             automatically - no date input needed from user
          d. Sets macro parameters and fires %include
          e. Logs outcome, updates request status
     4. Sends tiered notification emails
     5. Appends audit log
     6. Calls writeback.py to update Excel on SharePoint

   WHAT THE CAMPAIGN TEAM FILLS IN ON THE EXCEL:
     - Request ID
     - Campaign Code
     - Product Code
     - Reason for Redrop
     - Requested By
     - Approved By (if not self-approving)
     - Requested Redrop Date (optional - blank = run today)
     That is all. No drop date needed - looked up automatically.

   WHAT YOU DO PER CAMPAIGN (one time only):
     1. Build CMAxxxxx_DROP.sas using the template
     2. Drop it in &base_path.
     3. Done. Orchestrator finds it automatically.
   ============================================================ */

proc printto
  log="/data/fnbinsurance/Growth_Analytics/SASCODE/DEPLOYED/Logs/BGA/APN_DATA/STI_CA_D_ORCHESTRATOR.log"
  new;
run;

%include "/data/fnbins/fnbinsurance/Growth_Analytics/SASCODE/DEPLOYED/Automation/STI_CA_2/Libnames.sas";

options mprint mlogic symbolgen;


/* ============================================================
   CONFIGURATION — ONLY SECTION YOU EVER NEED TO EDIT
   ============================================================ */

/* Folder where all CMAxxxxx_DROP.sas files live              */
%let base_path        = /data/fnbinsurance/Growth_Analytics/SASCODE/DEPLOYED/Campaigns/;

/* SharePoint / network paths                                  */
%let sharepoint_path  = /data/fnb/shared/campaigns/redrop;
%let request_file     = &sharepoint_path./REDROP_REQUESTS.xlsx;
%let status_out_path  = &sharepoint_path./REDROP_STATUS_UPDATE.csv;

/* Notification                                                */
%let morris_email     = Morris.Nkomo@fnb.co.za;
%let ops_dl           = dlfnbstioperationalanalytics@fnb.co.za;

/* Python writeback script                                     */
%let python_writeback = /data/fnbinsurance/Growth_Analytics/SASCODE/DEPLOYED/Automation/STI_CA_2/writeback.py;

/* ============================================================
   END CONFIGURATION
   ============================================================ */


/* ============================================================
   SECTION 1: LOAD APPROVER REGISTER
   ============================================================ */

proc import
  datafile = "&request_file."
  out      = work.approvers_raw
  dbms     = xlsx replace;
  sheet    = "APPROVERS";
  getnames = yes;
run;

data work.approvers;
  set work.approvers_raw;
  name_clean           = upcase(strip(name));
  can_self_approve_flg = (upcase(strip(can_self_approve)) = "Y");
  keep name_clean can_self_approve_flg;
run;

proc sql noprint;
  select count(*) into :approver_count trimmed
  from work.approvers
  where can_self_approve_flg = 1;
quit;

%put NOTE: &approver_count. senior approvers loaded from register.;


/* ============================================================
   SECTION 2: LOAD AND VALIDATE REDROP REQUESTS
   ============================================================ */

proc import
  datafile = "&request_file."
  out      = work.requests_raw
  dbms     = xlsx replace;
  sheet    = "REDROP_REQUESTS";
  getnames = yes;
run;

/* Remove blank/placeholder rows pre-populated by Excel        */
data work.requests_raw_clean;
  set work.requests_raw;
  if strip(coalesce(request_id,    "")) ne "" and
     strip(coalesce(campaign_code, "")) ne "";
run;

/* Flag duplicate request_id values                            */
proc sql noprint;
  create table work.dup_check as
  select request_id, count(*) as n
  from work.requests_raw_clean
  group by request_id
  having count(*) > 1;

  select count(*) into :dup_id_count trimmed from work.dup_check;
quit;

%if &dup_id_count. > 0 %then %do;
  %put WARNING: &dup_id_count. duplicate Request ID(s) found - these will be skipped.;
%end;

data work.requests_deduped
     work.duplicate_requests;
  merge work.requests_raw_clean (in=a)
        work.dup_check          (in=b keep=request_id);
  by request_id;
  if b then output work.duplicate_requests;
  else      output work.requests_deduped;
run;

/* Validate and assess approval status                         */
proc sql;
  create table work.requests_assessed as
  select
    strip(r.request_id)            as request_id,
    upcase(strip(r.campaign_code)) as campaign_code,
    upcase(strip(r.product_code))  as product_code,
    strip(r.reason_for_redrop)     as reason_for_redrop,
    upcase(strip(r.requested_by))  as requested_by,
    upcase(strip(r.approved_by))   as approved_by,
    r.date_requested,

    /* Requested redrop date - blank means run today            */
    case
      when r.requested_redrop_date = . then today()
      else r.requested_redrop_date
    end as redrop_run_date format date9.,

    /* Flag past scheduled dates more than 7 days ago           */
    case
      when r.requested_redrop_date ne .
           and r.requested_redrop_date < today() - 7 then 1
      else 0
    end as past_redrop_date_flg,

    /* Flag campaign/product code mismatch                      */
    case
      when upcase(strip(r.campaign_code)) ne
           upcase(substr(strip(r.product_code), 1, length(strip(r.campaign_code))))
        then 1
      else 0
    end as code_mismatch_flg,

    /* Approval status                                          */
    case
      /* Already processed in a prior run - skip               */
      when upcase(strip(r.status)) not in ("PENDING") then upcase(strip(r.status))

      /* campaign/product code mismatch                        */
      when upcase(strip(r.campaign_code)) ne
           upcase(substr(strip(r.product_code), 1, length(strip(r.campaign_code))))
        then "REJECTED"

      /* Approved but requested run date not yet reached        */
      when r.requested_redrop_date ne . and r.requested_redrop_date > today()
        then "PENDING"

      /* Requester is senior - self approve                     */
      when a_req.can_self_approve_flg = 1 then "SELF_APPROVED"

      /* Approved by a valid senior                             */
      when a_app.can_self_approve_flg = 1 then "APPROVED"

      /* Approved_by filled but name not on register            */
      when upcase(strip(r.approved_by)) ne ""
           and a_app.name_clean is null then "REJECTED"

      /* Waiting for approval                                   */
      else "PENDING"
    end as approval_status,

    case
      when upcase(strip(r.campaign_code)) ne
           upcase(substr(strip(r.product_code), 1, length(strip(r.campaign_code))))
        then "Campaign code '"||strip(r.campaign_code)||
             "' does not match product code '"||strip(r.product_code)||"'"
      when upcase(strip(r.approved_by)) ne ""
           and a_app.name_clean is null
        then "Approver '"||strip(r.approved_by)||"' not in senior register"
      else ""
    end as reject_reason,

    case
      when r.requested_redrop_date ne . and r.requested_redrop_date > today()
        then "Scheduled for "||put(r.requested_redrop_date, date9.)||" - holding until then"
      when r.requested_redrop_date ne .
           and r.requested_redrop_date < today() - 7
        then "WARNING: requested redrop date "||
             put(r.requested_redrop_date, date9.)||
             " is >7 days in the past - treated as immediate run"
      else ""
    end as schedule_note,

    case
      when a_req.can_self_approve_flg = 1 then "SELF_APPROVED"
      when a_app.can_self_approve_flg = 1
        then "APPROVED_BY_"||strip(upcase(r.approved_by))
      else ""
    end as approval_type

  from work.requests_deduped r

  left join work.approvers a_req
    on upcase(strip(r.requested_by)) = a_req.name_clean

  left join work.approvers a_app
    on upcase(strip(r.approved_by))  = a_app.name_clean

  where upcase(strip(r.status)) = "PENDING"
     or upcase(strip(r.status)) ne "PROCESSED";
quit;

/* Split into buckets                                          */
data work.to_process
     work.still_pending
     work.rejected;
  set work.requests_assessed;
  select (approval_status);
    when ("SELF_APPROVED","APPROVED") output work.to_process;
    when ("PENDING")                  output work.still_pending;
    when ("REJECTED")                 output work.rejected;
    otherwise;
  end;
run;

proc sql noprint;
  select count(*) into :process_count  trimmed from work.to_process;
  select count(*) into :pending_count  trimmed from work.still_pending;
  select count(*) into :rejected_count trimmed from work.rejected;
quit;

%put NOTE: To process=&process_count. | Pending=&pending_count. | Rejected=&rejected_count.;


/* ============================================================
   SECTION 3: CORE ORCHESTRATION MACRO
   Resolves file path, looks up most recent drop date
   automatically from OFFER_CHECKOUT, injects parameters,
   and fires %include.
   ============================================================ */

%macro fire_campaign(
  request_id      =,
  campaign_code   =,
  product_code    =,
  approval_type   =,
  redrop_run_date =
);

  %let sas_file = &base_path.&campaign_code._DROP.sas;

  /* Step 1: Safety check - file must exist                    */
  %if %sysfunc(fileexist(&sas_file.)) = 0 %then %do;

    %put ERROR: =====================================================;
    %put ERROR: No SAS file found for &campaign_code..;
    %put ERROR: Expected: &sas_file.;
    %put ERROR: Request &request_id. cannot be processed.;
    %put ERROR: =====================================================;

    data work.failed_&request_id.;
      length request_id $20 fail_reason $200;
      request_id  = "&request_id.";
      fail_reason = "SAS file not found: &sas_file.";
    run;

    %return;

  %end;

  /* Step 2: Look up most recent drop date from OFFER_CHECKOUT */
  proc sql noprint;
    select max(load_date) into :drop_date_num trimmed
    from STI_PBI.OFFER_CHECKOUT
    where upcase(strip(product_code)) = upcase("&product_code.");
  quit;

  %if &drop_date_num. = . %then %do;

    %put ERROR: =====================================================;
    %put ERROR: No records found in OFFER_CHECKOUT for &product_code..;
    %put ERROR: Has this campaign been dropped before?;
    %put ERROR: Request &request_id. cannot be processed.;
    %put ERROR: =====================================================;

    data work.failed_&request_id.;
      length request_id $20 fail_reason $200;
      request_id  = "&request_id.";
      fail_reason = "No records in OFFER_CHECKOUT for product code: &product_code.";
    run;

    %return;

  %end;

  /* Format drop date for logging and for use in campaign file */
  %let drop_date = %sysfunc(putn(&drop_date_num., date9.));

  %put NOTE: ========================================;
  %put NOTE: Request      : &request_id.;
  %put NOTE: Campaign     : &campaign_code.;
  %put NOTE: Product      : &product_code.;
  %put NOTE: Drop Date    : &drop_date. (auto lookup);
  %put NOTE: Redrop Date  : &redrop_run_date.;
  %put NOTE: Approval     : &approval_type.;
  %put NOTE: File         : &sas_file.;
  %put NOTE: ========================================;

  /* Step 3: Inject parameters and fire the campaign file      */
  %let run_mode        = REDROP;
  %let redrop_run_date = &redrop_run_date.;

  %include "&sas_file.";

  %put NOTE: &campaign_code._DROP.sas completed for request &request_id.;

%mend fire_campaign;


/* ============================================================
   SECTION 4: ITERATE OVER APPROVED REQUESTS
   ============================================================ */

%macro run_orchestrator;

  %if &process_count. = 0 %then %do;
    %put NOTE: No approved requests to process today.;
  %end;

  %else %do;

    proc sql noprint;
      select
        request_id,
        campaign_code,
        product_code,
        approval_type,
        put(redrop_run_date, date9.)
      into
        :req_id_1      - :req_id_&process_count.,
        :req_camp_1    - :req_camp_&process_count.,
        :req_prod_1    - :req_prod_&process_count.,
        :req_apptype_1 - :req_apptype_&process_count.,
        :req_rundate_1 - :req_rundate_&process_count.
      from work.to_process;
    quit;

    data work.run_summary;
      length request_id $20 campaign_code $20 product_code $30
             approval_type $50 redrop_run_date $12
             outcome $20 fail_reason $200;
      stop;
    run;

    %do i = 1 %to &process_count.;

      %fire_campaign(
        request_id      = &&req_id_&i.,
        campaign_code   = &&req_camp_&i.,
        product_code    = &&req_prod_&i.,
        approval_type   = &&req_apptype_&i.,
        redrop_run_date = &&req_rundate_&i.
      );

      %let outcome = SUCCESS;
      %if %sysfunc(exist(work.failed_&&req_id_&i.)) %then %do;
        %let outcome = FAILED;
      %end;

      data work.run_summary;
        set work.run_summary;
        output;
        if _n_ = 0 then do;
          request_id      = "&&req_id_&i.";
          campaign_code   = "&&req_camp_&i.";
          product_code    = "&&req_prod_&i.";
          approval_type   = "&&req_apptype_&i.";
          redrop_run_date = "&&req_rundate_&i.";
          outcome         = "&outcome.";
          output;
        end;
      run;

      /* Append this request to run summary                    */
      data work.this_run;
        length request_id $20 campaign_code $20 product_code $30
               approval_type $50 redrop_run_date $12
               outcome $20 fail_reason $200;
        request_id      = "&&req_id_&i.";
        campaign_code   = "&&req_camp_&i.";
        product_code    = "&&req_prod_&i.";
        approval_type   = "&&req_apptype_&i.";
        redrop_run_date = "&&req_rundate_&i.";
        outcome         = "&outcome.";
      run;

      proc append base = work.run_summary
                  data = work.this_run force;
      run;

    %end;

  %end;

%mend run_orchestrator;

%run_orchestrator;


/* ============================================================
   SECTION 5: WRITE STATUS BACK TO SHAREPOINT CSV
   ============================================================ */

proc sql;
  create table work.status_updates as

  select
    request_id,
    case when outcome = "SUCCESS" then "PROCESSED" else "FAILED" end as new_status,
    case when outcome = "FAILED"
      then "Failed - check orchestrator log for details"
      else "Dropped to Optimise - check Optimise email for results"
    end as notes,
    put(today(), date9.) as processed_date
  from work.run_summary

  union all

  select
    request_id,
    "PENDING" as new_status,
    case
      when schedule_note ne "" then schedule_note
      else "Awaiting approval"
    end as notes,
    "" as processed_date
  from work.still_pending

  union all

  select
    request_id,
    "REJECTED"           as new_status,
    reject_reason        as notes,
    put(today(), date9.) as processed_date
  from work.rejected;
quit;

proc export
  data    = work.status_updates
  outfile = "&status_out_path."
  dbms    = csv replace;
run;


/* ============================================================
   SECTION 6: TIERED EMAIL NOTIFICATIONS
   ============================================================ */

%macro send_notifications;

  %let success_count = 0;
  %let failed_count  = 0;

  %if %sysfunc(exist(work.run_summary)) %then %do;
    proc sql noprint;
      select sum(outcome="SUCCESS") into :success_count trimmed from work.run_summary;
      select sum(outcome="FAILED")  into :failed_count  trimmed from work.run_summary;
    quit;
  %end;

  %let dup_id_count = 0;
  %if %sysfunc(exist(work.duplicate_requests)) %then %do;
    proc sql noprint;
      select count(*) into :dup_id_count trimmed from work.duplicate_requests;
    quit;
  %end;

  /* Duplicate request IDs                                     */
  %if &dup_id_count. > 0 %then %do;

    filename eml_dup email
      to      = "&morris_email."
      from    = "&ops_dl."
      subject = "Action Needed: &dup_id_count. Duplicate Request ID(s) Skipped - &sysdate9.";

    data _null_;
      file eml_dup;
      put "Hi Morris,";
      put " ";
      put "The following Request ID(s) appeared more than once in the";
      put "REDROP_REQUESTS sheet and were skipped entirely.";
      put "Please correct the duplicates and resubmit.";
      put " ";
      put "-----------------------------------------------";
    run;

    data _null_;
      file eml_dup mod;
      set work.duplicate_requests;
      put "Request ID    : " request_id;
      put "Campaign      : " campaign_code;
      put "Requested By  : " requested_by;
      put "-----------------------------------------------";
    run;

    data _null_;
      file eml_dup mod;
      put " ";
      put "Kind Regards,";
      put "Automated Campaign Operations";
    run;

  %end;

  /* Build requester email lookup                              */
  proc sql noprint;
    create table work.approvers_email as
    select name_clean, email_address
    from work.approvers_raw
    where strip(coalesce(email_address,"")) ne "";
  quit;

  /* Successfully dropped to Optimise                          */
  %if &success_count. > 0 %then %do;

    filename eml_ok email
      to      = "&morris_email."
      cc      = "&ops_dl."
      from    = "&ops_dl."
      subject = "FYI: &success_count. Redrop(s) Dropped to Optimise - &sysdate9.";

    data _null_;
      file eml_ok;
      put "Hi Morris,";
      put " ";
      put "The following redrop(s) were successfully dropped to the";
      put "Optimise intake folder today. Please monitor the Optimise";
      put "emails for the results of each file.";
      put " ";
      put "-----------------------------------------------";
    run;

    data _null_;
      file eml_ok mod;
      set work.run_summary;
      where outcome = "SUCCESS";
      put "Request ID    : " request_id;
      put "Campaign      : " campaign_code;
      put "Product Code  : " product_code;
      put "Approved via  : " approval_type;
      put "-----------------------------------------------";
    run;

    data _null_;
      file eml_ok mod;
      put " ";
      put "Kind Regards,";
      put "Automated Campaign Operations";
    run;

    /* Notify each requester individually                      */
    data _null_;
      set work.run_summary (where=(outcome="SUCCESS"));

      if _n_ = 1 then do;
        declare hash h(dataset:"work.approvers_email");
        h.defineKey("name_clean");
        h.defineData("email_address");
        h.defineDone();
      end;

      length req_email $100 req_name_clean $100;
      req_name_clean = upcase(strip(requested_by));
      rc = h.find(key:req_name_clean);
      if rc = 0 and strip(req_email) ne "" then do;
        filename eml_req email
          to      = req_email
          from    = "&ops_dl."
          subject = "Your Redrop Request "||strip(request_id)||" Has Been Dropped - &sysdate9.";
        file eml_req;
        put "Hi,";
        put " ";
        put "Your redrop request has been dropped to the Optimise";
        put "intake folder. Please monitor the Optimise emails for";
        put "the results.";
        put " ";
        put "Request ID    : " request_id;
        put "Campaign      : " campaign_code;
        put "Product Code  : " product_code;
        put " ";
        put "Kind Regards,";
        put "Automated Campaign Operations";
      end;
    run;

  %end;

  /* Failed                                                    */
  %if &failed_count. > 0 %then %do;

    filename eml_fail email
      to      = "&morris_email."
      from    = "&ops_dl."
      subject = "Action Needed: &failed_count. Redrop(s) Failed - &sysdate9.";

    data _null_;
      file eml_fail;
      put "Hi Morris,";
      put " ";
      put "The following redrop request(s) could not be processed.";
      put "This is usually because:";
      put "  1. No SAS file exists for the campaign code, OR";
      put "  2. The product code has no records in OFFER_CHECKOUT";
      put "     meaning this campaign has never been dropped before.";
      put " ";
      put "Expected file convention: CMAxxxxx_DROP.sas in &base_path.";
      put " ";
      put "-----------------------------------------------";
    run;

    data _null_;
      file eml_fail mod;
      set work.run_summary;
      where outcome = "FAILED";
      put "Request ID    : " request_id;
      put "Campaign      : " campaign_code;
      put "Product Code  : " product_code;
      put "-----------------------------------------------";
    run;

    data _null_;
      file eml_fail mod;
      put " ";
      put "Please check the orchestrator log for the specific error.";
      put " ";
      put "Kind Regards,";
      put "Automated Campaign Operations";
    run;

  %end;

  /* Pending approval                                          */
  %if &pending_count. > 0 %then %do;

    filename eml_pend email
      to      = "&morris_email."
      from    = "&ops_dl."
      subject = "Action Needed: &pending_count. Redrop(s) Awaiting Approval - &sysdate9.";

    data _null_;
      file eml_pend;
      put "Hi Morris,";
      put " ";
      put "The following redrop request(s) are waiting for a senior to";
      put "add their name in the 'Approved By' column of the SharePoint file.";
      put "The job will pick them up automatically at the next run.";
      put " ";
      put "-----------------------------------------------";
    run;

    data _null_;
      file eml_pend mod;
      set work.still_pending;
      put "Request ID    : " request_id;
      put "Campaign      : " campaign_code;
      put "Requested By  : " requested_by;
      put "Date Requested: " date_requested;
      put "Reason        : " reason_for_redrop;
      put "-----------------------------------------------";
    run;

    data _null_;
      file eml_pend mod;
      put " ";
      put "Kind Regards,";
      put "Automated Campaign Operations";
    run;

  %end;

  /* Rejected                                                  */
  %if &rejected_count. > 0 %then %do;

    filename eml_rej email
      to      = "&morris_email."
      from    = "&ops_dl."
      subject = "Alert: &rejected_count. Redrop Request(s) Rejected - &sysdate9.";

    data _null_;
      file eml_rej;
      put "Hi Morris,";
      put " ";
      put "The following request(s) were automatically rejected.";
      put "Please follow up with the requester.";
      put " ";
      put "-----------------------------------------------";
    run;

    data _null_;
      file eml_rej mod;
      set work.rejected;
      put "Request ID    : " request_id;
      put "Campaign      : " campaign_code;
      put "Requested By  : " requested_by;
      put "Reject Reason : " reject_reason;
      put "-----------------------------------------------";
    run;

    data _null_;
      file eml_rej mod;
      put " ";
      put "Kind Regards,";
      put "Automated Campaign Operations";
    run;

    /* Notify each requester individually                      */
    data _null_;
      set work.rejected;

      if _n_ = 1 then do;
        declare hash h(dataset:"work.approvers_email");
        h.defineKey("name_clean");
        h.defineData("email_address");
        h.defineDone();
      end;

      length req_email $100 req_name_clean $100;
      req_name_clean = upcase(strip(requested_by));
      rc = h.find(key:req_name_clean);
      if rc = 0 and strip(req_email) ne "" then do;
        filename eml_rej_req email
          to      = req_email
          from    = "&ops_dl."
          subject = "Your Redrop Request "||strip(request_id)||" Was Rejected - &sysdate9.";
        file eml_rej_req;
        put "Hi,";
        put " ";
        put "Your redrop request was automatically rejected.";
        put " ";
        put "Request ID    : " request_id;
        put "Campaign      : " campaign_code;
        put "Reject Reason : " reject_reason;
        put " ";
        put "Please correct the issue and resubmit, or contact Morris";
        put "if you believe this rejection was made in error.";
        put " ";
        put "Kind Regards,";
        put "Automated Campaign Operations";
      end;
    run;

  %end;

%mend send_notifications;
%send_notifications;


/* ============================================================
   SECTION 7: AUDIT LOG
   ============================================================ */

data work.audit_today;
  set work.requests_assessed;
  run_date = today(); format run_date date9.;
  run_time = time();  format run_time time9.;
run;

%macro append_audit;
  %if %sysfunc(exist(STI_PBI.REDROP_AUDIT_LOG)) = 0 %then %do;
    data STI_PBI.REDROP_AUDIT_LOG;
      set work.audit_today;
    run;
  %end;
  %else %do;
    proc append base = STI_PBI.REDROP_AUDIT_LOG
                data = work.audit_today force;
    run;
  %end;
%mend;
%append_audit;


/* ============================================================
   SECTION 8: LOG SUMMARY
   ============================================================ */

%put ============================================================;
%put ORCHESTRATOR COMPLETE - &sysdate9. &systime.;
%put ============================================================;
%put Requests dropped to Optimise : &success_count.;
%put Requests failed               : &failed_count.;
%put Requests pending approval     : &pending_count.;
%put Requests rejected             : &rejected_count.;
%put ============================================================;

proc printto;
run;


/* ============================================================
   SECTION 9: PYTHON WRITEBACK
   Updates REDROP_REQUESTS.xlsx on SharePoint with latest
   status from REDROP_STATUS_UPDATE.csv.
   ============================================================ */

x "python &python_writeback. ""&request_file."" ""&status_out_path.""";
