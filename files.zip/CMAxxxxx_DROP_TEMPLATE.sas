/* ============================================================
   CAMPAIGN FILE TEMPLATE
   FILE:     CMAxxxxx_DROP.sas
   RENAME TO: CMAxxxxx_DROP.sas  (replace xxxxx with campaign code)

   HOW THIS FILE IS CALLED:
     - INITIAL DROP: You run this file manually once.
     - REDROPS:      The orchestrator calls this automatically.

   PARAMETERS INJECTED BY ORCHESTRATOR (do not set manually):
     &run_mode.       = REDROP
     &campaign_code.  = CMAxxxxx
     &product_code.   = CMAxxxxxVxxMxx
     &drop_date.      = most recent load_date from OFFER_CHECKOUT
                        looked up automatically - no user input
     &request_id.     = request ID for audit log
     &redrop_run_date.= date this redrop is scheduled to run

   YOUR JOB:
     1. Fill in SECTION 1 (campaign config)
     2. Fill in SECTION 3 initial drop block only
     3. Save as CMAxxxxx_DROP.sas in the campaigns folder
     4. Run manually for the initial drop
     5. Hand off - redrops run automatically from here

   DO NOT CHANGE anything in:
     - SECTION 2 (run mode detection)
     - SECTION 3 redrop block (handled automatically)
     - SECTION 4 (drop to Optimise + audit log)
   ============================================================ */


/* ============================================================
   SECTION 1: CAMPAIGN CONFIGURATION
   *** FILL THIS IN FOR EACH NEW CAMPAIGN ***
   ============================================================ */

%let campaign_code = CMAxxxxx;
%let product_code  = CMAxxxxxVxxMxx;

%if %symexist(run_mode) = 0 %then %do;
  %let run_mode        = INITIAL;
  %let request_id      = INITIAL_&campaign_code.;
  %let redrop_run_date = %sysfunc(today(), date9.);
%end;

%if %symexist(redrop_run_date) = 0 %then
  %let redrop_run_date = %sysfunc(today(), date9.);

%put NOTE: ====================================================;
%put NOTE: Campaign : &campaign_code.;
%put NOTE: Product  : &product_code.;
%put NOTE: Run Mode : &run_mode.;
%put NOTE: Request  : &request_id.;
%put NOTE: ====================================================;


/* ============================================================
   SECTION 2: RUN MODE DETECTION
   DO NOT EDIT - standardised across all campaign files
   ============================================================ */

%let is_redrop = 0;
%if %upcase(&run_mode.) = REDROP %then %let is_redrop = 1;

%put NOTE: is_redrop flag = &is_redrop.;


/* ============================================================
   SECTION 3: POPULATION BUILD
   ============================================================

   FOR INITIAL DROPS:
   *** FILL IN THE INITIAL DROP BLOCK BELOW ***
   Build your full campaign opportunity and output it as
   work.drop_population with at minimum Cust_no and Product_Code.
   Do not apply governance, pressure, redlist or exclusion
   filters - Optimise handles all of that.

   FOR REDROPS:
   DO NOT EDIT - runs automatically.
   Looks up the most recent drop date from OFFER_CHECKOUT,
   pulls that exact population, and excludes only:
     1. Leads already successfully sent to Adobe
     2. Leads with permanent drop reasons
   Optimise re-evaluates everything else fresh on the day.
   ============================================================ */

%if &is_redrop. = 1 %then %do;

  /* ── REDROP: DO NOT EDIT ────────────────────────────────────*/

  /* Look up most recent drop date automatically               */
  proc sql noprint;
    select max(load_date) into :drop_date_num trimmed
    from STI_PBI.OFFER_CHECKOUT
    where upcase(strip(product_code)) = upcase("&product_code.");
  quit;

  %let drop_date = %sysfunc(putn(&drop_date_num., date9.));
  %put NOTE: Most recent drop date: &drop_date.;

  proc sql;
    create table work.drop_population as
    select
      ck.cust_no        as Cust_no,
      ck.product_code   as Product_Code

    from STI_PBI.OFFER_CHECKOUT ck

    left join STI_PBI.APNS_DATA a
      on  ck.cust_no      = a.cust_no
      and ck.product_code = a.product_code_to_adobe
      and ck.load_date    = a.date_to_adobe

    left join STI_PBI.DROP_REASON_REF r
      on upcase(strip(coalesce(a.drop_reason_to_adobe, "")))
       = upcase(strip(r.drop_reason))

    where upcase(strip(ck.product_code)) = upcase("&product_code.")
      and ck.load_date = &drop_date_num.
      and coalesce(a.Adobe, "")          ne "Loaded"
      and coalesce(r.retry_eligible, "Y") ne "N"
    ;
  quit;

  proc sql noprint;
    select count(*) into :pop_count trimmed
    from work.drop_population;
  quit;

  %put NOTE: Redrop population: &pop_count. leads eligible for resubmission;

%end;

%else %do;

  /* ── INITIAL DROP: *** FILL THIS IN *** ─────────────────────
     Replace the placeholder below with your campaign logic.

     EXAMPLE:
     libname src "/your/source/path";
     proc sql;
       create table work.drop_population as
       select ucn as Cust_no, "&product_code." as Product_Code
       from src.CMAxxxxx_OPPORTUNITY;
     quit;
     ──────────────────────────────────────────────────────────── */

  data work.drop_population;
    length Cust_no 8 Product_Code $30;
    stop;
  run;

  proc sql noprint;
    select count(*) into :pop_count trimmed
    from work.drop_population;
  quit;

  %put NOTE: Initial drop population: &pop_count. leads;

%end;

/* ============================================================
   END OF CAMPAIGN-SPECIFIC SECTION
   ============================================================ */


/* ============================================================
   SECTION 4: DROP TO OPTIMISE + AUDIT LOG
   DO NOT EDIT - standardised across all campaign files.
   ============================================================ */

%macro write_drop;

  %if &pop_count. = 0 %then %do;
    %put WARNING: ==============================================;
    %put WARNING: Zero leads in population for &campaign_code..;
    %put WARNING: No file will be dropped to Optimise.;
    %put WARNING: ==============================================;
  %end;

  %else %do;

    %let today_fmt    = %sysfunc(today(), yymmddn8.);
    %let optimise_dsn = &campaign_code._&today_fmt.;

    libname _optimIn "/data/fnb/clb/incoming_files/4_import_validation/in";

    data _optimIn.&optimise_dsn.;
      set work.drop_population;
    run;

    libname _optimIn clear;

    %put NOTE: ================================================;
    %put NOTE: Dropped to Optimise intake folder.;
    %put NOTE: Dataset : &optimise_dsn.;
    %put NOTE: Leads   : &pop_count.;
    %put NOTE: Campaign: &campaign_code.;
    %put NOTE: Request : &request_id.;
    %put NOTE: ================================================;

  %end;

  %let optimise_dsn_log = NOT DROPPED - ZERO LEADS;
  %if &pop_count. > 0 %then
    %let optimise_dsn_log = &campaign_code._&today_fmt.;

  data work.drop_log_entry;
    length campaign_code $20 product_code $30 request_id $30
           run_mode $10 redrop_run_date_str $12
           optimise_dataset $50 population_count 8
           log_date 8 log_time 8;
    campaign_code       = "&campaign_code.";
    product_code        = "&product_code.";
    request_id          = "&request_id.";
    run_mode            = "&run_mode.";
    redrop_run_date_str = "&redrop_run_date.";
    optimise_dataset    = "&optimise_dsn_log.";
    population_count    = &pop_count.;
    log_date            = today(); format log_date date9.;
    log_time            = time();  format log_time time9.;
  run;

  %if %sysfunc(exist(STI_PBI.CAMPAIGN_DROP_LOG)) = 0 %then %do;
    data STI_PBI.CAMPAIGN_DROP_LOG;
      set work.drop_log_entry;
    run;
  %end;
  %else %do;
    proc append base = STI_PBI.CAMPAIGN_DROP_LOG
                data = work.drop_log_entry force;
    run;
  %end;

  %put NOTE: Audit log updated for &campaign_code. request &request_id.;

%mend write_drop;
%write_drop;

/* ============================================================
   END OF CAMPAIGN FILE TEMPLATE
   ============================================================ */
