/* ============================================================
   CAMPAIGN FILE
   FILE:     CMA10252_DROP.sas
   CAMPAIGN: LOC - APN Campaign
   PRODUCT:  CMA10252V01M01
   ============================================================ */


/* ============================================================
   SECTION 1: CAMPAIGN CONFIGURATION
   ============================================================ */

%let campaign_code = CMA10252;
%let product_code  = CMA10252V01M01;

%if %symexist(run_mode) = 0 %then %do;
  %let run_mode        = INITIAL;
  %let request_id      = INITIAL_&campaign_code.;
  %let redrop_run_date = %sysfunc(today(), date9.);
%end;

%if %symexist(redrop_run_date) = 0 %then
  %let redrop_run_date = %sysfunc(today(), date9.);

%put NOTE: ====================================================;
%put NOTE: Campaign : &campaign_code.;
%put NOTE: Product  : &product_code.;
%put NOTE: Run Mode : &run_mode.;
%put NOTE: Request  : &request_id.;
%put NOTE: ====================================================;


/* ============================================================
   SECTION 2: RUN MODE DETECTION
   DO NOT EDIT - standardised across all campaign files
   ============================================================ */

%let is_redrop = 0;
%if %upcase(&run_mode.) = REDROP %then %let is_redrop = 1;

%put NOTE: is_redrop flag = &is_redrop.;


/* ============================================================
   SECTION 3: POPULATION BUILD
   ============================================================ */

%if &is_redrop. = 1 %then %do;

  /* ── REDROP: DO NOT EDIT ────────────────────────────────────
     Looks up most recent drop date automatically from
     OFFER_CHECKOUT, pulls that exact population, excludes
     already-sent and permanent drops, then re-applies the
     original sub-segment caps.                                */

  /* Look up most recent drop date                             */
  proc sql noprint;
    select max(load_date) into :drop_date_num trimmed
    from STI_PBI.OFFER_CHECKOUT
    where upcase(strip(product_code)) = upcase("&product_code.");
  quit;

  %let drop_date = %sysfunc(putn(&drop_date_num., date9.));
  %put NOTE: Most recent drop date: &drop_date.;

  /* Pull eligible leads                                       */
  proc sql;
    create table work.redrop_eligible as
    select
      ck.cust_no        as Cust_no,
      ck.product_code   as Product_Code,
      ck.sub_segment

    from STI_PBI.OFFER_CHECKOUT ck

    left join STI_PBI.APNS_DATA a
      on  ck.cust_no      = a.cust_no
      and ck.product_code = a.product_code_to_adobe
      and ck.load_date    = a.date_to_adobe

    left join STI_PBI.DROP_REASON_REF r
      on upcase(strip(coalesce(a.drop_reason_to_adobe, "")))
       = upcase(strip(r.drop_reason))

    where upcase(strip(ck.product_code)) = upcase("&product_code.")
      and ck.load_date = &drop_date_num.
      and coalesce(a.Adobe, "")           ne "Loaded"
      and coalesce(r.retry_eligible, "Y") ne "N"
    ;
  quit;

  /* Re-apply sub-segment caps                                 */
  /* Entry Wallet: max 80 000                                  */
  proc sql outobs=80000;
    create table work.rd_EW as
    select Cust_no, Product_Code from work.redrop_eligible
    where sub_segment = 'Entry Wallet';
  quit;

  /* Entry Banking: max 80 000                                 */
  proc sql outobs=80000;
    create table work.rd_EB as
    select Cust_no, Product_Code from work.redrop_eligible
    where sub_segment = 'Entry Banking';
  quit;

  /* Middle: max 80 000                                        */
  proc sql outobs=80000;
    create table work.rd_M as
    select Cust_no, Product_Code from work.redrop_eligible
    where sub_segment = 'Middle';
  quit;

  /* Emerging Affluent: max 40 000                             */
  proc sql outobs=40000;
    create table work.rd_EA as
    select Cust_no, Product_Code from work.redrop_eligible
    where sub_segment = 'Emerging Affluent';
  quit;

  /* Combine                                                   */
  proc sql;
    create table work.drop_population as
    select Cust_no, Product_Code from work.rd_EW union all
    select Cust_no, Product_Code from work.rd_EB union all
    select Cust_no, Product_Code from work.rd_M  union all
    select Cust_no, Product_Code from work.rd_EA;
  quit;

  proc sql noprint;
    select count(*) into :pop_count trimmed
    from work.drop_population;
  quit;

  %put NOTE: Redrop population: &pop_count. leads;

%end;

%else %do;

  /* ── INITIAL DROP ───────────────────────────────────────────*/

  %include "/data/fnbins/fnbinsurance/Growth_Analytics/SASCODE/DEPLOYED/Automation/STI_CA_2/Libnames.sas";
  %include '/data/fnbinsurance/Warehouse/00 Metadata/SAS Enhanced Libnames.sas';
  %include '/data/fnbinsurance/Warehouse/00 Metadata/SAS Raw Data Libnames.sas';

  libname STYR '/data/fnbins/fnbinsurance/Users/Tasha';
  libname REP2 "/data/fnb/clb/prod_data/7_tracking_views/Reporting_views";

  /* Derive P&P Segments                                       */
  data work.LOC_opportunity_enh;
    set STYR.styr_LOC_opportunity;
    length Segment_Derived $25;
    if SubSegment in ('Affluent','High Net Worth','Wealth','Ultra High Net Worth')
      then Segment_Derived = 'Private';
    else if SubSegment in ('Emerging Affluent','Entry Banking','Entry Wallet','Middle')
      then Segment_Derived = 'Personal';
    else Segment_Derived = 'Other';
  run;

  /* Exclude UCNs who already received APNs from related campaigns */
  proc sql;
    create table work.already_received as
    select distinct cust_no
    from REP2.ADOBE_STAKEHOLDERS_VIEW
    where
         upcase(product_code) like 'CMA08886%'  /* Gap Cover          */
      or upcase(product_code) like 'CMA08887%'  /* HCP                */
      or upcase(product_code) like 'CMA08888%'  /* Life Customized    */
      or upcase(product_code) like 'CMA08893%'  /* LLP                */
      or upcase(product_code) like 'CMA08894%'  /* Funeral            */
      or upcase(product_code) like 'CMA08896%'; /* Education Protector*/
  quit;

  proc sql;
    create table work.LOC_opportunity_enh2 as
    select * from work.LOC_opportunity_enh
    where UCN not in (select cust_no from work.already_received);
  quit;

  data work.LOC_opportunity_enh3;
    set work.LOC_opportunity_enh2;
    if   Segment_Derived = 'Personal' then Campaign = "&product_code.";
    else if Segment_Derived = 'Private'  then Campaign = "&product_code.";
  run;

  /* Apply sub-segment caps                                    */
  proc sql outobs=80000;
    create table work.LC_EW_F as
    select * from work.LOC_opportunity_enh3
    where SubSegment = 'Entry Wallet';
  quit;

  proc sql outobs=80000;
    create table work.LC_EB_F as
    select * from work.LOC_opportunity_enh3
    where SubSegment = 'Entry Banking';
  quit;

  proc sql outobs=80000;
    create table work.LC_M_F as
    select * from work.LOC_opportunity_enh3
    where SubSegment = 'Middle';
  quit;

  proc sql outobs=40000;
    create table work.LC_EA_F as
    select * from work.LOC_opportunity_enh3
    where SubSegment = 'Emerging Affluent';
  quit;

  proc sql;
    create table work.drop_population as
    select UCN as Cust_no, Campaign as Product_Code from work.LC_EW_F union all
    select UCN as Cust_no, Campaign as Product_Code from work.LC_EB_F union all
    select UCN as Cust_no, Campaign as Product_Code from work.LC_M_F  union all
    select UCN as Cust_no, Campaign as Product_Code from work.LC_EA_F;
  quit;

  proc sql noprint;
    select count(*) into :pop_count trimmed
    from work.drop_population;
  quit;

  %put NOTE: Initial drop population: &pop_count. leads;

%end;

/* ============================================================
   END OF CAMPAIGN-SPECIFIC SECTION
   ============================================================ */


/* ============================================================
   SECTION 4: DROP TO OPTIMISE + AUDIT LOG
   DO NOT EDIT - standardised across all campaign files.
   ============================================================ */

%macro write_drop;

  %if &pop_count. = 0 %then %do;
    %put WARNING: ==============================================;
    %put WARNING: Zero leads in population for &campaign_code..;
    %put WARNING: No file will be dropped to Optimise.;
    %put WARNING: ==============================================;
  %end;

  %else %do;

    %let today_fmt    = %sysfunc(today(), yymmddn8.);
    %let optimise_dsn = &campaign_code._&today_fmt.;

    libname _optimIn "/data/fnb/clb/incoming_files/4_import_validation/in";

    data _optimIn.&optimise_dsn.;
      set work.drop_population;
    run;

    libname _optimIn clear;

    %put NOTE: ================================================;
    %put NOTE: Dropped to Optimise intake folder.;
    %put NOTE: Dataset : &optimise_dsn.;
    %put NOTE: Leads   : &pop_count.;
    %put NOTE: Campaign: &campaign_code.;
    %put NOTE: Request : &request_id.;
    %put NOTE: ================================================;

  %end;

  %let optimise_dsn_log = NOT DROPPED - ZERO LEADS;
  %if &pop_count. > 0 %then
    %let optimise_dsn_log = &campaign_code._&today_fmt.;

  data work.drop_log_entry;
    length campaign_code $20 product_code $30 request_id $30
           run_mode $10 redrop_run_date_str $12
           optimise_dataset $50 population_count 8
           log_date 8 log_time 8;
    campaign_code       = "&campaign_code.";
    product_code        = "&product_code.";
    request_id          = "&request_id.";
    run_mode            = "&run_mode.";
    redrop_run_date_str = "&redrop_run_date.";
    optimise_dataset    = "&optimise_dsn_log.";
    population_count    = &pop_count.;
    log_date            = today(); format log_date date9.;
    log_time            = time();  format log_time time9.;
  run;

  %if %sysfunc(exist(STI_PBI.CAMPAIGN_DROP_LOG)) = 0 %then %do;
    data STI_PBI.CAMPAIGN_DROP_LOG;
      set work.drop_log_entry;
    run;
  %end;
  %else %do;
    proc append base = STI_PBI.CAMPAIGN_DROP_LOG
                data = work.drop_log_entry force;
    run;
  %end;

  %put NOTE: Audit log updated for &campaign_code. request &request_id.;

%mend write_drop;
%write_drop;

/* ============================================================
   END OF CAMPAIGN FILE
   ============================================================ */
