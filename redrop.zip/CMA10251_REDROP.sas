/* ============================================================
   STANDALONE REDROP SCRIPT
   CAMPAIGN: Motor - APN Campaign
   FILE:     CMA10251_REDROP.sas

   HOW TO USE:
     1. Run the entire file
     2. Monitor the log for confirmation of the drop
     3. Check the Optimise email for results

   This script automatically finds the most recent drop date
   from the Offer Checkout table and redrops all eligible
   leads from that drop to the Optimise intake folder.
   ============================================================ */

%include "/data/fnbins/fnbinsurance/Growth_Analytics/SASCODE/DEPLOYED/Automation/STI_CA_2/Libnames.sas";

%let campaign_code = CMA10251;
%let product_code  = CMA10251V01M01;

%put NOTE: ====================================================;
%put NOTE: STANDALONE REDROP - &campaign_code.;
%put NOTE: ====================================================;


/* ============================================================
   STEP 1: FIND THE MOST RECENT DROP DATE
   Looks up the latest load_date in OFFER_CHECKOUT for this
   product code and uses that as the original drop date.
   ============================================================ */

proc sql noprint;
  select max(load_date) into :drop_date_num trimmed
  from STI_PBI.OFFER_CHECKOUT
  where upcase(strip(product_code)) = upcase("&product_code.");
quit;

%if &drop_date_num. = . %then %do;
  %put ERROR: =====================================================;
  %put ERROR: No records found in OFFER_CHECKOUT for &product_code..;
  %put ERROR: Has this campaign been dropped before?;
  %put ERROR: =====================================================;
  %abort cancel;
%end;

/* Format for display and for date literal use in queries     */
%let drop_date_fmt = %sysfunc(putn(&drop_date_num., date9.));

%put NOTE: Most recent drop date found: &drop_date_fmt.;


/* ============================================================
   STEP 2: BUILD REDROP POPULATION
   Pulls from OFFER_CHECKOUT for the most recent drop date.
   Excludes:
     1. Leads already successfully sent to Adobe
     2. Leads with permanent drop reasons
   Then re-applies the original sub-segment caps with
   Criteria = F leads prioritised first.
   ============================================================ */

proc sql;
  create table work.redrop_eligible as
  select
    ck.cust_no                           as Cust_no,
    ck.product_code                      as Product_Code,
    ck.sub_segment,
    coalesce(ck2.Criteria, "")           as Criteria

  from STI_PBI.OFFER_CHECKOUT ck

  /* Identify leads already sent to Adobe                     */
  left join STI_PBI.APNS_DATA a
    on  ck.cust_no      = a.cust_no
    and ck.product_code = a.product_code_to_adobe
    and ck.load_date    = a.date_to_adobe

  /* Identify permanent drop reasons                          */
  left join STI_PBI.DROP_REASON_REF r
    on upcase(strip(coalesce(a.drop_reason_to_adobe, "")))
     = upcase(strip(r.drop_reason))

  /* Recover Criteria field from checkout                     */
  left join STI_PBI.OFFER_CHECKOUT ck2
    on  ck.cust_no      = ck2.cust_no
    and ck.product_code = ck2.product_code
    and ck.load_date    = ck2.load_date
    and ck2.load_type   = "Block"

  where upcase(strip(ck.product_code)) = upcase("&product_code.")
    and ck.load_date = &drop_date_num.

    /* Exclude: already successfully reached Adobe            */
    and coalesce(a.Adobe, "") ne "Loaded"

    /* Exclude: permanent drop reason                         */
    and coalesce(r.retry_eligible, "Y") ne "N"
  ;
quit;

proc sql noprint;
  select count(*) into :eligible_count trimmed
  from work.redrop_eligible;
quit;

%put NOTE: Eligible for redrop: &eligible_count. leads;

%if &eligible_count. = 0 %then %do;
  %put WARNING: =====================================================;
  %put WARNING: Zero leads eligible for redrop on &campaign_code..;
  %put WARNING: All leads either reached Adobe or have permanent drop reasons.;
  %put WARNING: No file will be dropped to Optimise.;
  %put WARNING: =====================================================;
  %goto exit;
%end;


/* ============================================================
   STEP 3: APPLY SUB-SEGMENT CAPS
   Re-applies the original caps with Criteria = F first.
   Entry Wallet    : max 80 000
   Entry Banking   : max 80 000
   Middle          : max 80 000
   Emerging Affluent: max 80 000
   ============================================================ */

/* Entry Wallet: max 80 000                                   */
proc sql outobs=80000;
  create table work.rd_EW as
  select Cust_no, Product_Code
  from work.redrop_eligible
  where sub_segment = 'Entry Wallet' and Criteria = 'F'
  union all
  select Cust_no, Product_Code
  from work.redrop_eligible
  where sub_segment = 'Entry Wallet' and Criteria ne 'F';
quit;

/* Entry Banking: max 80 000                                  */
proc sql outobs=80000;
  create table work.rd_EB as
  select Cust_no, Product_Code
  from work.redrop_eligible
  where sub_segment = 'Entry Banking' and Criteria = 'F'
  union all
  select Cust_no, Product_Code
  from work.redrop_eligible
  where sub_segment = 'Entry Banking' and Criteria ne 'F';
quit;

/* Middle: max 80 000                                         */
proc sql outobs=80000;
  create table work.rd_M as
  select Cust_no, Product_Code
  from work.redrop_eligible
  where sub_segment = 'Middle' and Criteria = 'F'
  union all
  select Cust_no, Product_Code
  from work.redrop_eligible
  where sub_segment = 'Middle' and Criteria ne 'F';
quit;

/* Emerging Affluent: max 80 000                              */
proc sql outobs=80000;
  create table work.rd_EA as
  select Cust_no, Product_Code
  from work.redrop_eligible
  where sub_segment = 'Emerging Affluent' and Criteria = 'F'
  union all
  select Cust_no, Product_Code
  from work.redrop_eligible
  where sub_segment = 'Emerging Affluent' and Criteria ne 'F';
quit;

/* Combine                                                    */
proc sql;
  create table work.drop_population as
  select Cust_no, Product_Code from work.rd_EW union all
  select Cust_no, Product_Code from work.rd_EB union all
  select Cust_no, Product_Code from work.rd_M  union all
  select Cust_no, Product_Code from work.rd_EA;
quit;

proc sql noprint;
  select count(*) into :pop_count trimmed
  from work.drop_population;
quit;

%put NOTE: Final redrop population: &pop_count. leads;


/* ============================================================
   STEP 4: DROP TO OPTIMISE INTAKE FOLDER
   Standard naming convention: CampaignCode_YYYYMMDD
   ============================================================ */

%let today_fmt    = %sysfunc(today(), yymmddn8.);
%let optimise_dsn = &campaign_code._&today_fmt.;

libname _optimIn "/data/fnb/clb/incoming_files/4_import_validation/in";

data _optimIn.&optimise_dsn.;
  set work.drop_population;
run;

libname _optimIn clear;

%put NOTE: ====================================================;
%put NOTE: Redrop complete.;
%put NOTE: Original drop date : &drop_date_fmt.;
%put NOTE: Leads resubmitted  : &pop_count.;
%put NOTE: Dataset dropped    : &optimise_dsn.;
%put NOTE: ====================================================;

%exit:;
